# Airline-Project
Airline Management Project

It is basically a simple implementation of an Airline Management System. 
Not that complex but should do the work for you.
Import the sql file "database_file.sql" in phpmyadmin.
To access the homepage of the website open "website.php".



And yes, I know I haven't use external css and I'm extremely sorry about that :p
